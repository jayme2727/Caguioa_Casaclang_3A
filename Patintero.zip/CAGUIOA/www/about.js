var game = new Phaser.Game(460, 580, Phaser.CANVAS, 'gameDiv');


var bg;
var back;
var jaime;
var section;
var syak;
var sikato;

var mainState = {

preload:function(){

    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;

    game.load.image("bg","img/bg.png");  
    game.load.image("back","img/home.png"); 
    game.load.image("jaime","img/ngaranko.png"); 
    game.load.image("section","img/sectionko.png"); 
    game.load.image("syak","img/jaime.jpg"); 

    },

create: function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);
        
    bg = game.add.tileSprite(0,0,800,600, "bg");

    back = game.add.button (405,0,"back",balik);
    back.scale.x= 1;
    back.scale.y= 1;

    jaime = game.add.image(125,430,"jaime");
    jaime.scale.x= .5;
    jaime.scale.y= .5;

    section = game.add.image(125,500,"section");
    section.scale.x= .5;
    section.scale.y= .5;

    syak = game.add.image(100,100,"syak");
    syak.scale.x= .5;
    syak.scale.y= .5;

},
update: function () {
    bg.tilePosition.x -=.5;
}
}
    function balik ()
    {
      window.location.href="index.html";
    }
    game.state.add("mainState",mainState);
    game.state.start("mainState");
var game = new Phaser.Game(460, 580, Phaser.CANVAS, 'gameDiv');


var bg;
var back; 
var player;
var opponent;
var opponent1;
var opponent2;
var opponent3;
var opponent4;
var btnright;
var btnleft;
var btnup;
var btndown;
var gameOverText;
var timeText;


var keyboard;

var mainState = {

preload:function(){

    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;


    game.load.image("bg","img/patintero.png");  
    game.load.image("back","img/home.png"); 
    game.load.spritesheet("player","img/prince.png",32,32); 
    game.load.spritesheet("opponent","img/player1.png",300,307); 
    game.load.spritesheet("opponent1","img/player1.png",300,307); 
    game.load.spritesheet("opponent2","img/player1.png",300,307); 
    game.load.spritesheet("opponent3","img/side.png",300,800); 
    game.load.spritesheet("opponent4","img/side.png",300,800);
    game.load.image("btnright","img/btnright.png"); 
    game.load.image("btnleft","img/btnleft.png"); 
	game.load.image("btnup","img/btnup.png"); 
    game.load.image("btndown","img/btndown.png"); 
    },

create: function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);
        
    bg = game.add.tileSprite(0,0,800,600, "bg");
    keyboard = game.input.keyboard.createCursorKeys();

    timer(20,1000);
	timeText = game.add.text(0,10,"Time: 20 ",{fill:"white"});
	gameOverText = game.add.text(150,250);// game over




    btnright = game.add.button(400,470,"btnright",walkright);
    btnright.scale.x = .1;
    btnright.scale.y= .1;
    btnleft = game.add.button(320,470,"btnleft",walkleft);
    btnleft.scale.x = .1;
    btnleft.scale.y= .1;
    btnup = game.add.button(350,420,"btnup",walkup);
    btnup.scale.x = .1;
    btnup.scale.y= .1;
    btndown = game.add.button(350,540,"btndown",walkdown);
    btndown.scale.x = .1;
    btndown.scale.y= .1;

    player = game.add.sprite(100,515,"player");
    player.animations.add('walk-right',[6,7,8],5,true);
    player.animations.add('walk-left',[3,4,5],5,true);
    player.animations.add('walk-up',[9,10,11],5,true);
    player.animations.add('walk-down',[0,1,2],5,true);


    game.physics.arcade.enable(player);

    opponent = game.add.sprite(80,160,"opponent");
    //opponent.animations.add('walk-right',[0,1,0,1],5,true);
    //opponent.animations.add('walk-left',[0,1,0,1],5,true);
    game.physics.arcade.enable(opponent);

    opponent1 = game.add.sprite(50,0,"opponent1");
    //opponent1.animations.add('walk-right',[0,1,0,1],5,true);
    //opponent1.animations.add('walk-left',[0,1,0,1],5,true);
    game.physics.arcade.enable(opponent1);

    opponent2 = game.add.sprite(310,325,"opponent2");
    //opponent2.animations.add('walk-right',[0,1,0,1],5,true);
    //opponent2.animations.add('walk-left',[0,1,0,1],5,true);
    game.physics.arcade.enable(opponent2);

    opponent3 = game.add.sprite(220,90,"opponent3");
    //opponent3.animations.add('walk-right',[0,1,0,1],5,true);
    //opponent3.animations.add('walk-left',[0,1,0,1],5,true);
    game.physics.arcade.enable(opponent3);


    opponent4 = game.add.sprite(220,450,"opponent4");
    //opponent3.animations.add('walk-right',[0,1,0,1],5,true);
    //opponent3.animations.add('walk-left',[0,1,0,1],5,true);
    game.physics.arcade.enable(opponent4);





    opponent.body.collideWorldBounds = true;
    //opponent.body.gravity.y = 1000;
    //opponent.body.bounce.y = 0.5;
    opponent.scale.y = 0.2;
    opponent.scale.x = 0.2;

    opponent1.body.collideWorldBounds = true;
    //opponent1.body.gravity.y = 1000;
    //opponent1.body.bounce.y = 0.5;
    opponent1.scale.y = 0.2;
    opponent1.scale.x = 0.2;

    opponent2.body.collideWorldBounds = true;
    //opponent2.body.gravity.y = 1000;
    //opponent2.body.bounce.y = 0.5;
    opponent2.scale.y = 0.2;
    opponent2.scale.x = 0.2;

	opponent3.body.collideWorldBounds = true;
    //opponent3.body.gravity.y = 1000;
    //opponent3.body.bounce.y = 0.5;
    opponent3.scale.y = 0.09;
    opponent3.scale.x = 0.09;

    opponent4.body.collideWorldBounds = true;
    opponent4.scale.y = 0.09;
    opponent4.scale.x = 0.09;


    var tween = game.add.tween(opponent).to( { x: 400},0,Phaser.Easing.Linear.None, true, 0,1000,true);
    var tween = game.add.tween(opponent1).to( { x: 390},0,Phaser.Easing.Linear.None, true, 0,1000,true);
    var tween = game.add.tween(opponent2).to( { x: 380},0,Phaser.Easing.Linear.None, true, 0,1000, true);
    var tween = game.add.tween(opponent3).to( { y: 100 },0, Phaser.Easing.Linear.None, true, 0, 300, true);
    var tween = game.add.tween(opponent4).to( { y: 0 },0, Phaser.Easing.Linear.None, true, 0, 50, true);
    
    player.body.collideWorldBounds = true;
    player.body.gravity.y = 100;
    //player.body.bounce.y = .01;
    player.scale.y = 1;
    player.scale.x = 1;

    back = game.add.button (410,0,"back",balik);
    back.scale.x= .8;
    back.scale.y= .8;

},
update: function () {
    //bg.tilePosition.x -=.5;

    game.physics.arcade.collide(opponent,player,collectPlayer);
    game.physics.arcade.collide(opponent1,player,collectPlayer);
    game.physics.arcade.collide(opponent2,player,collectPlayer);
    game.physics.arcade.collide(opponent3,player,collectPlayer);
    game.physics.arcade.collide(opponent4,player,collectPlayer);


   if(keyboard.left.isDown){
        // x++;
        player.animations.play("walk-left");
        player.body.velocity.x = -200;
        // bg.frame = 0;
    }
    else if(keyboard.right.isDown){
        // x--;
        // bg.frame = 1;
        player.animations.play("walk-right");
        player.body.velocity.x = 200;
    }
    else if(keyboard.up.isDown){
    	player.animations.play("walk-up");
        player.body.velocity.y = -200;
    }
    else if(keyboard.down.isDown){
    	player.animations.play("walk-down");
        player.body.velocity.y = 100;
    }
    else{
        player.body.velocity.x = 0;
        //player.animations.stop();
            player.body.velocity.y = 0;
            // // platform2.body.velocity.y = 0;
            //me.body.velocity.x = 0;
    }


}

}
    function balik ()
    {
      window.location.href="index.html";
    }

     function walkright(){
                btnright.frame =1;
                    player.animations.play("walk-right");
                    player.body.velocity.x = 200;
                }
                setTimeout(function(){
                    btnright.frame=0;
                },400)

            function walkleft(){
                btnleft.frame =1;
                        player.animations.play("walk-left");
                        player.body.velocity.x = -200;

                    }
                setTimeout(function(){
                    btnleft.frame=0;
                },400)
                 function walkup(){
                btnup.frame =1;
                        player.animations.play("walk-up");
                        player.body.velocity.y = -200;
                    }
                setTimeout(function(){
                    btnup.frame=0;
                },400)
                 function walkdown(){
                btndown.frame =1;
                        player.animations.play("walk-down");
                        player.body.velocity.y = 0;
                    }
                setTimeout(function(){
                    btndown.frame=0;
                },400)
        function collectPlayer(player,opponent){
                player.kill();
                gameOverText.text ="GAME OVER !! \n Tap to restart";
                game._paused = true;

                game.input.onTap.addOnce(restart,this);
            }

            function restart (){
        window.location.href = window.location.href;
        }
        function timer(initTime,microsec){
            setInterval(function(){
                initTime--;
                if(initTime>=0){        
                    timeText.text = "Time: "+initTime;
                }
                else{
                    game._paused = true;
                    gameOverText.text = "GAME OVER !! \n Tap to restart";
                    game.input.onTap.addOnce(restart,this);
                }
            },microsec);
        }


    game.state.add("mainState",mainState);
    game.state.start("mainState");